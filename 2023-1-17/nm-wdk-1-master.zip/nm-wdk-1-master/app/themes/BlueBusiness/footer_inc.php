<!-- start footer -->
		</div> <!-- CONTENT END -->

		<div id="border">
		<?=$config->sidebar2;?>
		</div>

	    </div>

            <div id="container-footer">
                 <div id="footer">
                    <div id="footer-copyright">
                    <?=$config->copyright;?>
                    </div>
                    <div id="footer-meta">
                    	<a href="http://validator.w3.org/check?uri=referer">XHTML</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> | <a href="http://www.christian-pansch.de" title="Webdesign Bremen">Design by christian-pansch.de</a> | Courtesy <a href="http://www.openwebdesign.org" target="_blank">Open Web Design</a></div></div>
            </div>

        </div> <!-- ENDE container -->
   </body>
</html>

