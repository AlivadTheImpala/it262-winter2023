      <footer>
        <div class="row">
          <div class="col-lg-12">
            
            <ul class="list-unstyled">
              <li class="pull-right"><a href="#top">Back to top</a></li>
            </ul>
			<p><?=$config->copyright;?>. Theme by <a href="http://bootswatch.com/">Bootswatch</a>, based on <a href="http://getbootstrap.com/css/">Bootstrap</a>.
			</p>

          </div>
        </div>
        
      </footer>
    

    </div>


    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="<?=THEME_PATH;?>js/bootstrap.min.js"></script>
    <script src="<?=THEME_PATH;?>js/bootswatch.js"></script>
  </body>
</html>